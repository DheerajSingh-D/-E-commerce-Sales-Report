# -E-commerce-Sales-Report
In the report, I utilized Power BI to analyze and provide insights into the sales performance of our e-commerce platform.
